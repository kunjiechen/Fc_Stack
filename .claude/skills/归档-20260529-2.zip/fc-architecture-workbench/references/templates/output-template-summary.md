# 《`<FC>` 软件架构设计》

**`<FC>`_软件架构设计**

**`<FC>` Software Architecture Design**

项目编号/Project number: `<FC>`
保密性/Security: 内部

**Document Properties**
Status: **草稿**
架构版本: **V1**
架构状态: **Draft**
Author: FC Architecture Workbench
Created: `<GenerationTime>`

**Approved Versions**

Current Document version **V1** is **Draft**.

**Approved Versions:**

- TBD

**Document Signatures**

| 版本 | 状态 | 审批人 | 日期 | 意见 |
| --- | --- | --- | --- | --- |
| V1 | Draft | TBD | TBD | TBD |

## 适用说明

本文档适用于 `<FC>` 模块的软件架构设计定义。本文档描述模块的外部接口、依赖接口、配置参数、状态机设计、故障设计、全局变量设计、内存分配与文件族设计，不描述详细实现方案、代码细节或测试用例步骤。

---

## 文档修订记录

| 版本 | 日期 | 作者 | 变更说明 | 状态 |
| --- | --- | --- | --- | --- |
| V1 | `<GenerationDate>` | FC Architecture Workbench | `<ChangeSummary>` | Draft |

---

## 目录

- [1 FC总结介绍](#1-fc总结介绍)
- [2 外部接口设计](#2-外部接口设计)
- [3 依赖接口设计](#3-依赖接口设计)
- [4 配置参数设计](#4-配置参数设计)
  - [4.1 配置宏参](#41-配置宏参)
  - [4.2 配置参数](#42-配置参数)
- [5 状态机设计](#5-状态机设计)
  - [5.1 芯片工作模式](#51-芯片工作模式)
  - [5.2 软件状态机](#52-软件状态机)
  - [5.3 状态转换详表](#53-状态转换详表)
- [6 故障设计](#6-故障设计)
  - [6.1 故障分类](#61-故障分类)
  - [6.2 故障策略维度定义](#62-故障策略维度定义)
  - [6.3 故障全链路表](#63-故障全链路表)
- [7 全局变量设计](#7-全局变量设计)
  - [7.1 外部全局变量](#71-外部全局变量)
  - [7.2 静态全局变量](#72-静态全局变量)
  - [7.3 标定变量](#73-标定变量)
- [8 内存分配宏定义](#8-内存分配宏定义)
- [9 文件列表与文件关系](#9-文件列表与文件关系)
  - [9.1 文件列表](#91-文件列表)
  - [9.2 文件关系](#92-文件关系)
  - [9.3 内部函数分解](#93-内部函数分解)
- [10 架构风险与待确认](#10-架构风险与待确认)
- [附录：架构元信息](#附录架构元信息)

---

## 1. FC总结介绍

- **架构版本**: `V1` / `V2` / `V3`
- **架构状态**: `Draft` / `Released`
- **生成时间**: `<GenerationTime>`
- **变更点总结**: (初版写"初版生成"；升级/更新时用一句话概括主要变化)
- **FC名称**: `<FC>`
- **FC功能介绍**: (中文完整段落；层级名、接口名、架构术语可保留英文)
- **应用场景**: (中文完整段落；层级名、接口名、架构术语可保留英文)
- **架构设计思路**: (中文完整段落；包含 MainFunction 决策及理由、Callout 归并策略、执行模型、关键设计取舍)
- **AUTOSAR架构层级**:
- **当前软件架构所处层级**: (e.g. `IoExtDev`, `IoHwAb`, `Cdd`, `Srv`)

说明：
- 当前软件架构所处层级填写项目的正式层级名，如 `IoExtDev`、`IoHwAb`、`Srv`、`Cdd` 等。
- 若项目已有固定层级归属，直接落正式结论，不展开过程性讨论。
- 版本号仅使用 `V1`、`V2`、`V3` 这种整数大版本，不使用 `V1.0`、`V1.1`。
- 仅需求文档输入时生成 `V1`；正式架构文件 + 需求文档输入时升级到下一大版本；草稿架构更新不升级版本。

---

## 2. 外部接口设计

每个函数优先单独描述，避免 PDF 生成时因超宽表格影响可读性。

### 2.x `FC_FunctionName`

| Interface Prototype | Description | Sync/Async | Reentrancy | Return Value | Basic Constraints |
| --- | --- | --- | --- | --- | --- |
| `Std_ReturnType FC_GetXxx(uint16 Id_u16, uint32* Xxx_pu32)` | English description of what this function does, when it should be called, and what it returns. | Synchronous / Asynchronous | Reentrant / Non-reentrant | `E_OK` on success; `E_NOT_OK` if ... | Initialization dependency, parameter validity, core ownership, pointer non-null, state constraints. |

说明：
- 接口原型按项目正式风格展示，写出完整 C 函数原型。
- 函数名前缀必须保留输入中的 FC/驱动名称，不得自动 CamelCase 化。
- `Description` 使用英文完整句子，描述函数做什么、何时调用、返回值含义。
- `Basic Constraints` 简述初始化前置条件、参数范围、输出指针非空、当前核归属、调用时序等。
- `Init` 和 `MainFunction`（如存在）必须列入本节。
- 所有对外接口在此列出，不做接口遗漏。
- 若存在故障检测、诊断判定或异常状态上报，本节默认应包含一个可读取的故障/诊断状态接口。
- **`Init` 接口必须附带初始化执行序列表**：在 API 描述表之后，增加有序步骤表，每步包含操作描述、前置条件、成功判据、失败处理。

**Init 执行序列模板**：

```markdown
**初始化执行序列**：

| Step | 操作 | 前置条件 | 成功判据 | 失败处理 |
|------|------|---------|---------|---------|
| 1 | 加载编译期配置常量（默认模式、超时阈值、去抖次数） | 模块已加载 | 配置值在有效范围内 | 若配置值非法：DET 上报 + 返回 E_NOT_OK |
| 2 | 验证所有依赖 Callout 可用（函数指针非空） | Step1 完成 | 所有 Callout 非空 | 缺失任一 Callout：DET 上报 + 设置状态为 UNINIT + 返回 |
| 3 | 设置芯片为默认模式（通过 Callout 写控制引脚） | Step2 完成 | Callout 返回 E_OK | 写入失败：重试 1 次；仍失败 → DET 上报 + 返回 |
| 4 | 等待芯片模式切换稳定（≥ 模式切换超时阈值） | Step3 完成 | 超时时间已过 | 超时不影响 Init 返回（模式在 MainFunction 中异步确认） |
| 5 | 初始化运行时状态容器：状态机、故障标志、去抖计数器、DET buffer 清零 | Step4 完成 | 状态机 ≠ UNINIT，所有计数器 = 0 | 内存访问异常：DET 上报 + 返回 |
| 6 | 标记模块已初始化 | Step5 完成 | 初始化标志 = true | — |
```

---

## 3. 依赖接口设计

每个依赖接口优先单独描述。依赖接口紧接外部接口——两者都是"接口"，外部是 FC 对外承诺，依赖是 FC 对平台的需求。

### 3.x `FC_CalloutFunctionName`

| Interface Prototype | Description | Sync/Async | Reentrancy | Return Value | Basic Constraints | Implemented By | Evidence | Status |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `Std_ReturnType FC_CalloutXxx(uint16 Id_u16, uint8* Data_pu8, uint16 Size_u16)` | English description of what this callout does, when the FC calls it, and what it returns. | Synchronous / Asynchronous | Reentrant / Non-reentrant | `E_OK` on success; `E_NOT_OK` on failure. | Pointer parameters must be non-null. Callout implementation must be reentrant. | MCAL / IoMcu / IoExtDev / Service Layer / Project Adaptation | Requirement or architecture evidence for this dependency. | `Formal` / `Conditional` |

说明：
- 本节仅体现依赖接口（Callout 原型），不与 FC 对外接口混排。
- 当 FC 需要操作 DIO、PWM、SPI、I2C 或平台资源时，应抽象为依赖接口/Callout。
- 依赖接口/Callout 函数名前缀必须保留输入中的 FC/驱动名称。
- Callout 原型中不允许使用数组形参写法（`TxData_au8[]`），必须使用指针形参。
- `Implemented By` 可为 `MCAL`、`IoMcu`、`IoExtDev`、`Service Layer` 或 `Project Adaptation`。
- 不允许 FC 直接调用裸 MCAL API、直接操作寄存器或直接绑定具体驱动。

---

## 4. 配置参数设计

本章区分两类配置载体：

- **配置宏参**（`Cfg.h`）：编译期宏开关，控制功能使能、行为选择、容量上限。所有宏标识符 ALL_CAPS。
- **配置参数**（`Cfg.c` / `CfgData.h`）：编译期常量数据，含引脚映射表、查找表、阈值数组。以 `const` 全局数据形式存在，不在 `Cfg.h` 中逐项展开为宏。

### 4.1 配置宏参

| Macro | Purpose | Type | Default Value | Evidence | Usage Location | Status |
| --- | --- | --- | --- | --- | --- | --- |
| `FC_CFG_DEV_ERROR_DETECT` | Global feature switch for development error detection. | Feature Enable | `STD_ON` | Requirement/rule evidence for parameter checking or DET. | `FC_Cfg.h`, external API parameter checks. | `Formal` |

配置宏参说明：
- 仅体现通过必要性检查的正式配置宏参数。`Macro` 必须是全大写 C 宏标识符。
- 不体现各核内配置宏参、各核实例数、核内映射表、硬件绑定明细。
- 不为运行态变量、标定参数、每个外部接口、内部 helper 或硬件映射项生成宏。
- 硬件引脚到 DIO 通道号的映射属于配置参数（§4.2），不在本节展开为逐引脚宏。
- 不生成软件版本宏（`CFG_SW_MAJOR_VERSION`、`CFG_SW_MINOR_VERSION`）。
- `Status` 取值：`Formal`、`Conditional`、`Pending Confirmation`、`Not Recommended`。

### 4.2 配置参数

| Parameter | Type | Purpose | Carrier | Evidence | Status |
| --- | --- | --- | --- | --- | --- |
| DIO Pin Mapping Table | `const uint16[]` | Maps logical pin index to physical DIO channel ID. Indexed by pin enum in `FC_Types.h`. | `FC_CfgData.h` (extern) / `FC_Cfg.c` (definition) | Chip architecture view A2 pin list. | `Formal` |

配置参数说明：
- 本节承载 `Cfg.c` / `CfgData.h` 中的编译期常量数据，不是 `Cfg.h` 中的宏。
- 常见类型：引脚映射表、DIO 通道 ID 数组、模式控制真值表、阈值/超时常量数组、I2C 器件地址常量。
- 引脚映射表使用逻辑索引（`FC_Types.h` 中定义的 enum）到物理通道 ID 的映射。
- 不要将配置参数表中的每个条目拆成独立宏写入 `Cfg.h`。
- `Status` 取值同 §4.1。

---

## 5. 状态机设计

本章定义完整的软件状态机——包含芯片硬件支持的工作模式 + 驱动层为管理这些模式所需的软件状态。是详细设计阶段状态机代码骨架的直接输入。

### 5.1 芯片工作模式

芯片硬件定义的运行模式（从数据手册提取，不做软件加工）。

| 模式名 | 硬件行为 | INH 状态 | 总线状态 | CAN 收发 | 功耗特征 |
| --- | --- | --- | --- | --- | --- |
| Normal | 正常收发，总线偏置 0.5VCC | HIGH | 在线 | 收发使能 | 正常 |
| Listen-only | 仅接收，发送器禁用，总线偏置 0.5VCC | HIGH | 在线 | 仅接收 | 正常 |
| Standby | 低功耗接收器监控总线，总线偏置到地 | HIGH | 在线（仅监控） | 禁用 | 低功耗 |
| Go-to-Sleep | 同 Standby + 发出 sleep 命令 | HIGH | 在线（仅监控） | 禁用 | 低功耗 |
| Sleep | 低功耗接收器，总线偏置到地，INH 浮空 | 浮空 | 在线（仅监控） | 禁用 | 极低功耗 |

### 5.2 软件状态机

驱动层为管理芯片模式引入的软件状态。在芯片工作模式之上增加了软件管控状态（UNINIT、过渡态等），且区分软件主动切换和硬件强制切换两种转换路径。

**5.2.1 状态枚举与编码**

| 状态名 | 编码 | 类型 | 说明 |
| --- | --- | --- | --- |
| UNINIT | 0x00 | 软件状态 | 模块加载后、Init 完成前的初始状态 |
| NORMAL | 0x01 | 芯片模式 | 正常收发模式，对应芯片 Normal |
| LISTEN_ONLY | 0x02 | 芯片模式 | 仅接收模式，对应芯片 Listen-only |
| STANDBY | 0x03 | 芯片模式 | 第一级低功耗，对应芯片 Standby |
| GO_TO_SLEEP | 0x04 | 软件过渡态 | 睡眠前过渡，对应芯片 Go-to-Sleep。th 到期后自动转 SLEEP |
| SLEEP | 0x05 | 芯片模式 | 第二级低功耗，对应芯片 Sleep |

**5.2.2 状态转换图**

```
                         ┌──────────┐
                Init ──→ │  UNINIT  │ (软件状态)
                         └──────────┘
                              │ Init Step6 完成
                              ▼
                   ┌─────────────────────┐
                   │   DEFAULT_MODE      │←──────────────────────┐
                   │ (NORMAL 或 STANDBY) │                       │
                   └──────┬──────────────┘                       │
                          │ SetDevModeOutSig                      │
                          ▼                                       │
          ┌──────────────────────────────────┐                    │
          │  NORMAL ←→ LISTEN_ONLY           │                    │
          │    ↓ SetDevMode(GO_TO_SLEEP)     │                    │
          │    ↓         ↕                   │                    │
          │ STANDBY ←→ GO_TO_SLEEP → SLEEP  │                    │
          └──────────────────────────────────┘                    │
                   │          │          │                        │
                   │ UVBAT    │ UVNOM    │ WAKE                   │
                   ▼          ▼          └────────────────────────┘
               STANDBY      SLEEP      (Wake→Standby→Normal)
              (硬件强制)   (硬件强制)

软件主动切换: SetDevModeOutSig() → CalloutDioWrite 控制 STB_N/EN
硬件强制切换: MainFunction 中 DetectModeChange() 异步检测
过渡态: GO_TO_SLEEP — 保持 th 后芯片硬件自动转入 SLEEP，软件在 MainFunction 中确认
```

**5.2.3 软件状态机变量设计**

状态机相关的运行时变量（定义在 `FC.c` 静态全局区，§7.2 中统一汇总）：

| 变量 | 类型 | 说明 | 生命周期 |
| --- | --- | --- | --- |
| `ModeState_e` | enum | 当前软件状态（含 UNINIT + 5 个芯片模式 + 过渡态） | Init 置 DEFAULT；SetDevModeOutSig/MainFunction 更新 |
| `RequestedMode_e` | enum | 最近一次 SetDevModeOutSig 请求的目标模式（用于 GO_TO_SLEEP 过渡态校验） | SetDevModeOutSig 写入；MainFunction 确认后清除 |
| `LastModeBeforeSleep_e` | enum | 进入 Sleep 前的模式（用于 UV 恢复后还原） | 进入 Sleep 前锁存；UV 恢复后使用 |

### 5.3 状态转换详表

| 当前状态 | 触发事件 | 目标状态 | 触发源 | 软件动作 | 芯片进入动作 | 时序约束 |
| --- | --- | --- | --- | --- | --- | --- |
| UNINIT | `Init()` Step6 完成 | DEFAULT_MODE | 软件 | 设置 ModeState=DEFAULT；清零故障标志和计数器 | 按 STB_N/EN 进入对应芯片模式 | — |
| NORMAL | `SetDevModeOutSig(LISTEN_ONLY)` | LISTEN_ONLY | 软件 | 查模式真值表 → CalloutDioWrite(STB_N=H, EN=L)；更新 ModeState | 禁用发送器 | 切换后等 ≥8μs 再读 ERR_N |
| LISTEN_ONLY | `SetDevModeOutSig(NORMAL)` | NORMAL | 软件 | CalloutDioWrite(STB_N=H, EN=H)；更新 ModeState | 使能发送器 | 同上 |
| NORMAL | `SetDevModeOutSig(STANDBY)` | STANDBY | 软件 | CalloutDioWrite(STB_N=L, EN=L)；更新 ModeState | 总线偏置到地；仅低功耗接收器 | — |
| STANDBY | `SetDevModeOutSig(NORMAL)` | NORMAL | 软件 | CalloutDioWrite(STB_N=H, EN=H)；更新 ModeState | 总线偏置回 0.5VCC | 切换后等 ≥8μs |
| NORMAL | `SetDevModeOutSig(GO_TO_SLEEP)` | GO_TO_SLEEP | 软件 | 锁存 RequestedMode=SLEEP；CalloutDioWrite(STB_N=L, EN=H)；更新 ModeState=GO_TO_SLEEP；启动 th 计时 | 启动 th 计时器 | th=20~50μs 后芯片自动转 SLEEP |
| GO_TO_SLEEP | MainFunction 检测到 th 到期 + INH=LOW | SLEEP | 硬件→软件确认 | 锁存 LastModeBeforeSleep；更新 ModeState=SLEEP | INH 浮空 | th=20~50μs |
| GO_TO_SLEEP | STB_N/EN 变化或 Wake 置位（th 到期前） | 对应模式 | 硬件 | MainFunction 检测 → 取消 sleep；更新 ModeState | 取消 Sleep 进入 | — |
| NORMAL / LISTEN_ONLY | MainFunction 检测到 INH=LOW + INH 之前为 HIGH（UVNOM 判定） | SLEEP | 硬件→软件确认 | 锁存 LastModeBeforeSleep；记录欠压事件（§6.3）；更新 ModeState=SLEEP | INH 浮空；总线偏置到地 | tdet(uv)=100~350ms |
| 任意 | MainFunction 检测到状态机意外为 STANDBY + VBAT 欠压（UVBAT 判定） | STANDBY | 硬件→软件确认 | 记录 VBAT 欠压事件（§6.3） | 总线脱离（零负载） | — |
| STANDBY / SLEEP | MainFunction 检测到 Wake 标志置位（ERR_N/RXD 为 LOW） | STANDBY | 硬件→软件确认 | 清除 UVNOM 定时器；更新 ModeState=STANDBY；调用 HandleWakeReason 判定唤醒源 | INH 激活 | twake=5~50μs（本地）/ 唤醒模式 0.5~2ms（远程） |
| SLEEP | UVNOM 恢复（INH 重新变 HIGH + VCC/VIO 恢复） | 按 STB_N/EN 恢复 | 硬件→软件确认 | MainFunction 检测 → 查 LastModeBeforeSleep → 重新初始化 → 更新 ModeState | INH 激活 | trec(uv)=1~5ms |
| STANDBY | UVBAT 恢复 | 按 STB_N/EN 恢复 | 硬件→软件确认 | MainFunction 检测 → 确认模式 → 更新 ModeState | 总线重新连接 | — |

说明：
- **触发源**：软件 = API 调用直接控制；硬件→软件确认 = 芯片硬件行为先在 MainFunction 中检测到，软件确认后更新状态变量。
- **软件动作**列是驱动代码执行的操作——这是软件状态机和芯片状态机耦合的关键列。
- **芯片进入动作**列描述芯片硬件行为，软件不可控，仅能观测。
- 软件状态机变量在 §7.2 静态全局变量中统一声明，此处仅引用。

---

## 6. 故障设计

本章定义每条故障的检测→确认→响应→快照→恢复→清除全生命周期。是详细设计阶段 MainFunction 故障处理骨架和故障存储结构的直接输入。

### 6.1 故障分类

| 分类 | 说明 | 示例 |
| --- | --- | --- |
| `hardware_chip` | 芯片硬件检测并上报的故障，通过引脚电平或寄存器标志反映 | UVNOM、UVBAT、过温、TXD 超时、总线短路 |
| `software_state` | 软件运行时状态异常 | 未初始化访问、状态机非法转换 |
| `software_param` | API 调用参数非法 | 空指针、超范围参数、非法模式值 |

### 6.2 故障策略维度定义

每条故障从触发到闭环需定义以下 6 个策略维度。架构层给出策略决策，详细设计层按决策实现具体逻辑。

| 策略维度 | 定义 | 架构层需决策的内容 | 典型选项 |
| --- | --- | --- | --- |
| **确认策略** | 故障触发后，如何判定它是真实故障而非瞬态干扰 | 确认方式 + 阈值 | `芯片自判定` / `连续 2 次 MainFunction` / `连续 3 次 MainFunction` |
| **故障响应** | 确认后立即执行的动作 | 软件动作粒度 | `LogOnly` / `DET+ReturnError` / `DisableTx` / `ForceSleep` |
| **快照策略** | 故障确认时刻锁存哪些运行时数据，用于根因分析 | 锁存数据范围 | `None` / `ModeSnapshot` / `PinLevelSnapshot` / `FullContext`（具体字段待项目确认） |
| **恢复策略** | 故障条件消失后，如何恢复正常运行 | 恢复方式 | `Auto`（芯片自恢复） / `Manual`（软件主动恢复） / `Reset`（需复位） / `Fatal`（不可恢复） |
| **清除策略** | 故障恢复后，如何清除故障标志和快照数据 | 清除条件 | `EnterNormal` / `ReadClear` / `ApiClear` / `PowerOnReset` |
| **影响范围** | 故障存在期间，哪些功能受影响 | 影响的功能域 | `FullChip` / `TxOnly` / `SingleCall` / `BusDisconnect` |

### 6.3 故障全链路表

| 故障名称 | 分类 | 检测机制 | 确认策略 | 故障响应 | 快照策略 | 恢复策略 | 清除策略 | 影响范围 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| UVNOM | hardware_chip | VCC/VIO 欠压 > tdet(uv) → 芯片进 Sleep，INH 浮空。MainFunction 中 DetectModeChange 检测 INH=LOW + 状态机变化 | 连续 2 次 MainFunction 确认 | 记录欠压事件；DET 上报；锁存 LastModeBeforeSleep | ModeSnapshot（锁存当前模式） | Auto（VCC+VIO 恢复 > trec(uv) 后芯片自动退出） | PowerOnReset（重新初始化） | FullChip |
| UVBAT | hardware_chip | VBAT < Vuvd(VBAT) → 芯片进 Standby，总线脱离。MainFunction 中 DetectModeChange 检测 | 连续 2 次 MainFunction 确认 | 记录 VBAT 欠压事件 | ModeSnapshot | Auto（VBAT 恢复后芯片自动恢复） | Auto（VBAT 恢复自动清除） | BusDisconnect |
| TXD 超时 | hardware_chip | TXD 持续显性 > tto(dom)TXD → 芯片禁用发送器。MainFunction 在 Listen-only 模式通过 PollErrN 读 Local failure | 芯片自判定 | 记录本地故障；DET 上报 | None | Auto（MCU 释放 TXD 后芯片自动恢复） | EnterNormal | TxOnly |
| 过温 | hardware_chip | 结温 > Tj(sd) → 芯片禁用发送器。MainFunction 中 PollErrN 读 Local failure | 芯片自判定 | 记录过温事件；DET 上报 | FullContext（故障计数+模式） | Auto（降温后芯片自动恢复） | Auto（降温自动清除） | TxOnly |
| 总线短路 | hardware_chip | 4 对 TXD 显隐边沿内检测 CANH/CANL 短路 → Bus failure 标志置位。Normal 模式通过 PollErrN 读取 | 芯片自判定 | 记录总线故障；DET 上报 | None | Manual（重新进入 Normal 重试） | EnterNormal 或 PowerOnReset | TxOnly |
| 未初始化访问 | software_state | 各 API 入口检查初始化标志 | 单次触发即确认 | DET 上报；返回 E_NOT_OK | FullContext（调用 API ID + 参数） | Manual（调用 Init 后恢复） | ApiClear（Init 成功后清除） | SingleCall |
| 非法参数 | software_param | 各 API 入口检查参数范围/指针非空 | 单次触发即确认 | DET 上报；返回 E_NOT_OK | FullContext（非法参数值 + API ID） | Manual（调用方修正参数） | Auto（仅当次返回错误） | SingleCall |
| 非法状态转换 | software_state | SetDevModeOutSig 检查目标模式是否在 §5.3 合法转换集合中 | 单次触发即确认 | DET 上报；返回 E_NOT_OK | FullContext（请求模式+当前模式） | Manual（调用方传入合法模式） | Auto（仅当次返回错误） | SingleCall |

说明：
- **确认策略**：芯片硬件自判定故障无需软件去抖。仅外部信号读取类故障（INH 判断欠压）需多次确认防瞬态。
- **快照策略**：`None`=芯片行为确定，快照无额外诊断价值。`FullContext`=锁存数据辅助根因分析，具体字段由项目诊断需求确认。
- ASIL-D 要求硬件故障+软件故障全覆盖。

---

## 7. 全局变量设计

本章定义模块所有全局数据：对外暴露的（无）、内部静态的、以及标定可调的。变量按单核/多核执行模型确定归属。

### 7.1 外部全局变量

| 变量 | 状态 | 说明 |
| --- | --- | --- |
| `Empty` | `Empty` | 架构不允许对外提供全局变量输出。所有外部访问通过 §2 的函数接口。 |

### 7.2 静态全局变量

定义在 `FC.c` 中的 `static` 变量。归属和隔离策略由 SRS CORE 需求决定（单核=全局唯一，多核=per-core 独立）。

| 变量 | 类型 | 归属 | 说明 | 关联章节 | 初始化 |
| --- | --- | --- | --- | --- | --- |
| `ModeState_e` | enum | per-core（多核）/ global（单核） | 当前软件状态机状态 | §5.2 | Init Step5 → DEFAULT_MODE |
| `RequestedMode_e` | enum | per-core / global | SetDevModeOutSig 请求的目标模式 | §5.2 | Init Step5 → DEFAULT_MODE |
| `LastModeBeforeSleep_e` | enum | per-core / global | 进入 Sleep 前锁存的模式，用于恢复 | §5.2 | Init Step5 → UNINIT |
| `FaultFlags_u32` | uint32 | per-core / global | 故障标志位集合（bit0=UVNOM, bit1=UVBAT, ...），§6.3 的运行时载体 | §6.3 | Init Step5 → 0x00000000 |
| `FaultDebounceCounters_au8[]` | uint8[] | per-core / global | 每条故障的去抖计数器数组（按需 N 个） | §6.3 | Init Step5 → 全 0 |
| `FaultSnapshot` | struct | per-core / global | 故障快照数据存储（按 §6.2 快照策略决定字段） | §6.2 | Init Step5 → 全 0 |
| `DETBuffer` | struct[] | per-core / global | DET 错误记录 buffer（newest-error overwrite） | — | Init Step5 → 全 0；条件：DEV_ERROR_DETECT=STD_ON |
| `InitFlag_b` | boolean | per-core / global | 模块已初始化标志 | §2 Init | 模块加载 → false；Init Step6 → true |
| `WakeReason_e` | enum | per-core / global | 最近一次唤醒源（Local / Remote / PowerOn） | §5.3 | Init Step5 → PowerOn |

### 7.3 标定变量

| 变量 | 类型 | 默认值 | 说明 | 状态 |
| --- | --- | --- | --- | --- |
| `Empty` | `N/A` | `N/A` | 当前无确认的标定变量。阈值和时序参数均归类为编译期配置（§4），不属于标定流程可调参数。 | `Empty` |

说明：
- 标定变量仅在项目明确需要标定工具链时填充，IoExtDev 族默认 Empty。
- 若项目后续引入标定需求（如可调故障阈值、可调去抖次数），在此节增加对应变量并标注 `Conditional`。

---

## 8. 内存分配宏定义

| Memory Section | Target Content | Start Macro | Stop Macro | Used Files | Notes |
| --- | --- | --- | --- | --- | --- |
| CODE | All external API implementations and internal static helper functions. | `FC_CODE_START` | `FC_CODE_STOP` | `FC.c`, `FC_Callout.c` | Standard CODE section. |
| RUNTIME RAM (per core) | All static global variables (§7.2): state machine, fault flags, debounce counters, DET buffer, snapshot storage. | `FC_CLEAR_FAR_DATA_ALIGN4_COREx_START` | `FC_CLEAR_FAR_DATA_ALIGN4_COREx_STOP` | `FC.c` | Default `CLEAR_FAR_DATA`; per-core with `COREx` notation. Single-core uses CORE0. |
| CONST (global shared) | Configuration data shared across cores: mode truth tables, default values. | `FC_CONST_FAR_DATA_ALIGN4_GLOBAL_START` | `FC_CONST_FAR_DATA_ALIGN4_GLOBAL_STOP` | `FC_Cfg.c`, `FC_CfgData.h` | Shared config constants. |
| CONST (per core) | Per-core configuration tables: pin mapping tables, per-core instance configuration. | `FC_CONST_FAR_DATA_ALIGN4_COREx_START` | `FC_CONST_FAR_DATA_ALIGN4_COREx_STOP` | `FC_Cfg.c`, `FC_CfgData.h` | Each core has its own config data region. |
| CALIB | Calibration variables (§7.3). | `FC_CONST_FAR_DATA_ALIGN4_CALI_START` | `FC_CONST_FAR_DATA_ALIGN4_CALI_STOP` | `FC_Cali.c` / `FC_CfgData.h` | Only rendered when §7.3 is not Empty. |

说明：
- `CONST` 不能默认只给 GLOBAL；必须同时包含 GLOBAL 和 per-core。
- 仅当 FC 控制 SPI/I2C/寄存器型外设时，才增加 `REG CONST` 行。引脚直连型设备不渲染。
- 仅当 §7.3 非空时，才渲染 `CALIB` 行。
- RUNTIME RAM 段承载 §7.2 所有静态全局变量。单核使用 CORE0，多核使用 COREx 模式。

---

## 9. 文件列表与文件关系

### 9.1 文件列表

| File | Required/Optional | Responsibility | Key Content |
| --- | --- | --- | --- |
| `FC.c` | Required | Driver implementation file. | External API implementations (§2), internal static helpers (§9.3), static global variables (§7.2). |
| `FC.h` | Required | External interface header file. | External API prototypes, `CODE_START/STOP` section macros. |
| `FC_Types.h` | Required | Type definitions header file. | State enums (§5.2), fault flag bit definitions (§6.3), variable struct types (§7.2), pin index enums, config container structs. |
| `FC_Cfg.h` | Required | Configuration macro header file. | Feature switches, behavior selection macros (§4.1). Includes `Std_Types.h`. |
| `FC_Cfg.c` | Required | Configuration data implementation file. | Pin mapping tables (§4.2), mode control truth tables, per-core config tables. |
| `FC_CfgData.h` | Required | Configuration data declaration header file. | `extern` declarations for config tables and containers. |
| `FC_Callout.h` | Conditional | Platform adaptation interface header file. | Callout prototypes (§3). Required when Callout dependencies exist. |
| `FC_Callout.c` | Conditional | Platform adaptation implementation file. | Callout integration stubs. Required when Callout dependencies exist. |
| `FC_MemMap.h` | Required | Memory section mapping header file. | MemMap macro definitions (§8). |

### 9.2 文件关系

| File | Direct Dependency | Relationship Description |
| --- | --- | --- |
| `FC_Cfg.h` | `Std_Types.h` (external) | References `Std_ReturnType`, `uint8/uint16/uint32`, `boolean`, `STD_ON/STD_OFF`. |
| `FC_Types.h` | `FC_Cfg.h` | Type definitions depend on configuration macros. |
| `FC_Callout.h` | `FC_Types.h` | Callout prototypes reference FC public types. |
| `FC_CfgData.h` | `FC_Types.h` | Config data declarations reference types (pin index enum, config struct). |
| `FC.h` | `FC_Types.h` | External API header uses FC types in prototypes. |
| `FC.c` | `FC.h` | Implements external APIs. |
| `FC.c` | `FC_Callout.h` | Calls hardware and platform callouts (§3). |
| `FC.c` | `FC_MemMap.h` | Places code and runtime data into memory sections (§8). |
| `FC_Cfg.c` | `FC_CfgData.h` | Defines config tables. |
| `FC_Cfg.c` | `FC_MemMap.h` | Places config const data into memory sections. |
| `FC_Callout.c` | `FC_Callout.h` | Implements callout stubs. |
| `FC_Callout.c` | `FC_MemMap.h` | Places callout adaptation code into memory sections. |
| `FC_MemMap.h` | All FC-created section-managed files | Included at section boundaries. |

说明：
- 仅当 FC 控制 SPI/I2C/寄存器型外设时，才渲染 `FC_Reg.h` 行。引脚直连型不渲染。
- 若 FC 存在 Callout 依赖，必须同时列出 `FC_Callout.h` 与 `FC_Callout.c`。

### 9.3 内部函数分解

架构层定义关键内部静态函数的职责和调用关系，不写实现代码。这是详细设计阶段 `FC.c` 函数拆分的直接输入。

**内部函数清单**：

| 函数名 | 职责 | 被调用者 | 操作的数据 |
| --- | --- | --- | --- |
| `ValidateConfig` | 校验编译期配置宏值在合法范围内 | `Init()` (Step 1) | `FC_Cfg.h` 配置宏值 |
| `VerifyCallouts` | 检查所有依赖 Callout 函数指针非空 | `Init()` (Step 2) | Callout 函数指针表 |
| `ApplyModePinCtrl` | 根据目标模式查表设置控制引脚 | `SetDevModeOutSig()` / `Init()` (Step 3) | 模式控制真值表 + 引脚映射表 (§4.2) |
| `InitStaticVariables` | 初始化所有静态全局变量（§7.2） | `Init()` (Step 5) | §7.2 全部变量 |
| `PollStatusPins` | 读取状态引脚电平，解析当前模式下的含义 | `MainFunction()` | ERR_N / INH / WAKE 引脚 |
| `DetectModeChange` | 检测硬件触发的模式变化，更新 ModeState | `MainFunction()` | INH 引脚 + ModeState_e (§5.2) |
| `DebounceFault` | 对指定故障进行去抖判定（§6.2 确认策略） | `MainFunction()` | FaultDebounceCounters_au8[] (§7.2) |
| `UpdateFaultFlags` | 汇总各故障检测结果，更新 FaultFlags_u32 | `MainFunction()` | FaultFlags_u32 (§7.2) |
| `HandleWakeReason` | 判定唤醒源（Local/Remote），更新 WakeReason_e | `MainFunction()` (唤醒后首次) | WakeReason_e (§7.2) |

**调用层次**：

```
Init()
  ├── ValidateConfig()
  ├── VerifyCallouts()
  ├── ApplyModePinCtrl()      → CalloutDioWrite
  └── InitStaticVariables()

SetDevModeOutSig()
  └── ApplyModePinCtrl()      → CalloutDioWrite

MainFunction()
  ├── PollStatusPins()        → CalloutDioRead
  ├── DetectModeChange()      → 更新 ModeState_e, LastModeBeforeSleep_e
  ├── DebounceFault()         (× N 个故障)
  │   └── 查表: §6.3 确认策略 → 更新 FaultDebounceCounters_au8[]
  ├── UpdateFaultFlags()      → 更新 FaultFlags_u32
  └── HandleWakeReason()      (条件：唤醒后首次)

GetDevModeInSig()  → 读 ModeState_e (§7.2)
GetDevFaultSig()   → 读 FaultFlags_u32 (§7.2)
```

---

## 10. 架构风险与待确认

填写说明：
- 可以直接修改下表的 `状态` 和 `备注`，也可以在当前窗口直接回复。
- `状态` 只允许填写：`待评审`、`已评审`、`待修改`。

| 索引 | 问题项 | 问题/风险 | 影响 | 建议动作 | 备注 | 状态 |
| --- | --- | --- | --- | --- | --- | --- |
| R1 | Pending item | 中文描述风险或待确认问题。 | 中文描述影响范围。 | 中文描述建议动作。 | 用户填写。 | `待评审` |
| R-OTHER | 其他 | 用户补充的其他建议或风险。 | 用户填写。 | 用户填写。 | 无其他建议。 | `待评审` |

说明：
- 每条风险项必须有稳定索引。必须保留 `R-OTHER` / `其他` 行。
- 若任一真实风险项仍为 `待评审` 或 `待修改`，架构状态必须保持 `Draft`。
- 所有真实风险项均为 `已评审` 后，才允许从 `Draft` 发布为 `Released`。

---

## 附录：架构元信息

- **架构版本**: `V1` / `V2` / `V3`
- **架构状态**: `Draft` / `Released`
- **生成时间**: `<GenerationTime>`
- **生成/修订说明**:
- **版本策略**: 仅正式架构文件 + 需求文档触发大版本升级。
- **发布条件**: 所有真实风险项均为 `已评审`。
- **变更点总结【简洁版】**:
  - 初版生成 / 草稿更新 / 正式版本升级。
  - 外部接口、依赖接口、配置、状态机、故障设计、全局变量、MemMap、文件结构或风险状态变化。

---

## 下一步：评审与发布引导

当前架构状态为 **V1 Draft**。请通过以下方式完成评审：

- **推荐评审方式 1**：直接修改第 10 章风险表中的 `状态` 和 `备注` 列。
- **推荐评审方式 2**：在当前窗口回复，例如 `R1、R2 已评审；R4 待修改，备注：按 xxx 方案调整`。
- 如果所有风险项均认可，可回复：**`全部已评审，R-OTHER 无其他建议，直接发布`**。
- 修改完成后仍保持 `V1 Draft`，直到所有真实风险项均为 `已评审` 后发布为 **V1 Released**。
- 草稿评审发布不升级版本；只有正式架构文件 + 新需求文档才升级到下一大版本。
